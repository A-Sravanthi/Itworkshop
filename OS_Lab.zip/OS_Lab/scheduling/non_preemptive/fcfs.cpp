#include<bits/stdc++.h>
using namespace std;
struct pro
{
    int at,bt,ct,tat,no;
};

int main()
{
   int n;
   cout<<"enter the number of process"<<endl;
   cin>>n;
   pro p[n];
  int max_t=INT_MIN;
   for(int i=0;i<n;i++)
   {
     p[i].no=i+1;
     cin>>p[i].at>>p[i].bt;
      max_t=max(max_t,p[i].at);
   }
    int count=0;
    for(int i=0;i<=max_t;i++)
    {
        int f=0;
        for(int j=0;j<n;j++)
        {
            if(p[j].at==i)
            {
                f=1;
                cout<<count<<" "<<"P"<<p[j].no<<" "<<count+p[j].bt<<endl;
                count+=p[j].bt;
                p[j].ct=count;
            }
        }
        if(f==0 and count<=i)
        {
            cout<<count<<" idle"<<count+1<<endl;
            count++;
        }
    }
    for(int i=0;i<n;i++)
    {
      cout<<p[i].no<<" "<<p[i].ct<<endl;
      }
    
    
   }
     

    
    
