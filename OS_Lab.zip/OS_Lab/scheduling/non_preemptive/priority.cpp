#include<bits/stdc++.h>
using namespace std;
struct pro
{
   int at,bt,ct,tat,no,pri;
};
void sort(pro p[],int n, pro a[])
{
    for(int i=0;i<n-1;i++)
    {
        for(int j=0;j<n-i-1;j++)
        {

         if(p[j].pri>p[j+1].pri)
         {
            pro t=p[j];
            p[j]=p[j+1];
            p[j+1]=t;
         }   
           
    }
    }
   
    int min=INT_MAX;
    for(int i=0;i<n;i++)
    {
      if(p[i].at<min)
        min=p[i].at;
    }
    int j=1;
    for(int i=0;i<n;i++)
    {
        if(p[i].at==min)
        {
            a[0]=p[i];
        }
        else
        {
            a[j++]=p[i];
        }
    }
}

void calculate(pro a[],int n)
{
    int count=0;
    if(a[0].at==0)
    {
        count=0;
    }
    else{
        count+=a[0].at;
    }
    int i=0;
    while(i<n)
    {
        if(count>=a[i].at)
        {
            count+=a[i].bt;
            a[i].ct=count;
            i++;
        }
        else
        count=a[i].at;
    }
}
int main()
{
    int n;
    cout<<"enter the n"<<endl;
    cin>>n;
    pro p[n];
    for(int i=0;i<n;i++)
    {
        cin>>p[i].at>>p[i].bt>>p[i].pri;
        p[i].no=i+1;
    }
    pro a[n];
    sort(p,n,a);
    calculate(a,n);
    cout<<"completion times"<<endl;
    for(int i=0;i<n;i++)
    {
        cout<<"P"<<a[i].no<<" "<<a[i].ct<<endl;
    }



}