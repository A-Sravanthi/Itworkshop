#include<bits/stdc++.h>
using namespace std;
struct pro
{
    int pid;
    vector<int>all;
    vector<int>need;
    vector<int>max;
};
int main()
{
    int n,m,x;
    cout<<"Enter n"<<endl;
    cin>>n;
    pro p[n];
    cout<<"enter no of resources"<<endl;
    cin>>m;
    cout<<"enter allocation matrix"<<endl;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            cin>>x;
            p[i].all.push_back(x);
        }
    }
    cout<<"Enter the max matrix"<<endl;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            cin>>x;
            p[i].max.push_back(x);
        }
    }
    cout<<"enter the available matrix"<<endl;
    vector<int>avl;
    for(int i=0;i<m;i++)
    {
         cin>>x;
         avl.push_back(x);
    }
    cout<<"The need matrix is"<<endl;
    for(int i=0;i<n;i++)
    {
        for( int j=0;j<m;j++)
        {
            p[i].need.push_back(p[i].max[j]-p[i].all[j]);
            cout<<p[i].need[j]<<" ";
        }
        //cout<<endl;
    }
    vector<bool>used(n);
    vector<int>seq;
    for(int k=0;k<n;k++)
    {
        for(int i=0;i<n;i++)
        {
            bool yes=true;
            if(!used[i])
            {
                for(int j=0;j<m;j++)
                {
                    if(p[i].need[j]>avl[j])
                    {
                        yes=false;
                        break;
                    }
                }
                if(yes)
                { 
                    for(auto j=0;j<m;j++)
                    { 
                        avl[j]+=p[i].all[j];
                    }
                    used[i]=true;
                    seq.push_back(i);
                    break;
            }

        }
    }
    }
    if(seq.size()!=n)
    {
        cout<<"There is  deadlock"<<endl;
    }
    else
    {
        for(int i=0;i<n;i++)
        {
            cout<<seq[i]<<"->";
        }
    }
    
 
}
