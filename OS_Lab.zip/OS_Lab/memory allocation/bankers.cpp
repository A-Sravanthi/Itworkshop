#include<bits/stdc++.h>
using namespace std;
struct pro
{
    int pid;
    vector<int>all;
    vector<int>max;
    vector<int>need;
};
int main()
{
    cout<<"enter no of procesess"<<endl;
    int n,x,m;
    cin>>n;
    pro p[n];
    cout<<"enter no of resources";
    cin>>m;
    cout<<"enter allocation matrix"<<endl;
    for(int i=0;i<n;i++)
    { 
        
        for(int j=0;j<m;j++)
        {
            cin>>x;
            p[i].all.push_back(x);
        }
    }
    cout<<"enter the max matrix"<<endl;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            cin>>x;
            p[i].max.push_back(x);
        }
    }
   
    cout<<"enter available matrix"<<endl;
    vector<int>avl;
    for(int i=0;i<m;i++)
    {
        cin>>x;
       avl.push_back(x);
    }
    cout<<"The neeed matrix"<<endl;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
         int y=p[i].max[j]-p[i].all[j];
         p[i].need.push_back(y);
        }
    }
    
    for(int i=0;i<n;i++)
    { 
         cout<<"P"<<i;
        for(int j=0;j<m;j++)
        {
            cout<<p[i].need[j]<<" ";
        }
        cout<<endl;
    }
    vector<bool>used(n);
    vector<int>seq;
    for(int k=0;k<n;k++)
    {
        for(int i=0;i<n;i++)
        {
            bool yes=true;
            
                if(!used[i])
                {
                    for(auto j=0;j<m;j++)
                    {
                        if(p[i].need[j]>avl[j])
                        {
                            yes=false;
                            break;
                        }
                    } 
                    if(yes)
                    {
                       for(auto j=0;j<m;j++)
                       {
                          avl[j]+=p[i].all[j];
                       }
                       used[i]=true;
                       seq.push_back(i);
                       break;
                    }
                }
            
        }
    }
    if(seq.size()!=n)
    {
        cout<<"There is a deadllock"<<endl;
    }
    else{
        cout<<"The sequence of the processess"<<endl;
    for(int i=0;i<n;i++)
    {
        cout<<"P"<<seq[i]<<"->";
    }
    }
}
