#include<bits/stdc++.h>
using namespace std;

struct fit {
    int a, no, b, pno,intf;
};
void fragmentation(fit m[],fit p[],int n,int k)
{
    int msum=0;
    for(int i=0;i<n;i++)
    {
       if(m[i].b==-1)
       {  
         msum+=m[i].a;
       }
    }
    int psum=0;
    for(int i=0;i<k;i++)
    {
        if(p[i].b==-1)
        {
         psum+=p[i].a;    
        }
    }
    if(msum>=psum)
    {
        cout<<"External fragmenttion is"<<msum<<endl;
    }
    else{
        cout<<"Extenral frag is :0"<<endl;
    }
}

void print(fit m[], fit p[], int k) {
    cout << "Pro " << "Block " << "Size  " <<"frag"<<endl;
    for(int i = 0; i < k; i++) {
        if(m[i].b != -1)
            cout << m[i].pno << "    " << m[i].no << "    " << m[i].a <<"   "<<m[i].intf<<endl;
        
    }

}
void worstfit(fit m[],fit p[],int n,int k)
{
    for(int i=0;i<k;i++)
    {
        int ind=-1;
        int max=INT_MIN;
        for(int j=0;j<n;j++)
        {
            if((m[j].a>=p[i].a) && (m[j].b==-1 && p[i].b==-1))
            {
                if((m[j].a-p[i].a)>max)
                {
                    max=m[j].a-p[i].a;
                    ind=j;
                }
            }

        }
        if(ind!=-1)
        {
            m[ind].pno=p[i].no;
            m[ind].b=p[i].b=0;
            m[ind].intf=m[ind].a-p[i].a;
            m[ind].a=p[i].a;
        }
   }
   print(m,p,n);
}
void bestfit(fit m[], fit p[], int n, int k) {
    for(int i = 0; i < k; i++) {
        int min = INT_MAX;
        int ind = -1;
        for(int j = 0; j < n; j++) {
            if((m[j].a >= p[i].a) && (p[i].b == -1 && m[j].b == -1)) {
                if((m[j].a - p[i].a) < min) {
                    min = m[j].a - p[i].a;
                    ind = j;
                }
            }
        }
        if(ind != -1) {
            m[ind].pno = p[i].no;
            m[ind].b = p[i].b = 0;
            m[ind].intf=m[ind].a-p[i].a;
            m[ind].a=p[i].a;
        }
    }
    print(m, p, n);
}

int main() {
    int n, k;
    cout << "enter no of blocks" << endl;
    cin >> n;
    fit m[n];
    cout << "Enter blocks sizes" << endl;
    for(int i = 0; i < n; i++) {
        cin >> m[i].a;
        m[i].no = i + 1;
        m[i].b = -1;
        m[i].intf=0;
    }
    cout << "Enter no of process" << endl;
    cin >> k;
    fit p[k];
    cout << "enter process sizes " << endl;
    for(int i = 0; i < k; i++) {
        cin >> p[i].a;
        p[i].no = i + 1;
        p[i].b = -1;
    }
    //bestfit(m, p, n, k);
    
    worstfit(m,p,n,k);
    fragmentation(m,p,n,k);
}
