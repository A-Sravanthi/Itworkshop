#include<bits/stdc++.h>
using namespace std;
struct fit
{
    int a,b,no,pno;
};
void print(fit m[],int k)
{
  cout<<"Block"<<"Process"<<"size"<<endl;
   for(int i=0;i<k;i++)
    {
       if(m[i].b!=-1)
       {
         cout<<m[i].no<<"   "<<m[i].pno<<"      "<<m[i].a<<endl;
    }
}
}
void worstfit(fit m[],fit p[],int n,int k)
{
    for(int i=0;i<k;i++)
    {
        int max=INT_MIN;
        int ind=-1;
        for(int j=0;j<n;j++)
        {
            if((p[i].a<=m[j].a) && (p[i].b==-1 && m[j].b==-1))
            {
                if((m[j].a-p[i].a)>max)
                {
                    max=m[j].a-p[i].a;
                    ind=j;
                }
            }
        }
        if(ind!=-1)
        {
             cout<<m[ind].no<<" "<<p[i].no<<endl;
             m[ind].pno=p[i].no;
             m[ind].b=p[i].b=0;
        }
    }
   // print(m,k);
}
void bestfit(fit m[],fit p[],int n,int k)
{
    for(int i=0;i<k;i++)
    {
        int min=INT_MAX;
        int ind=-1;
        for(int j=0;j<n;j++)
        {
            if((p[i].a<=m[j].a) && (p[i].b==-1 and m[j].b==-1))
            {
                   if((m[j].a-p[i].a)<min)
                   {
                      min=m[j].a-p[i].a;
                      ind=j;
                   }
             }
            
        }
        if(ind!=-1)
        {
            m[ind].a=p[i].a;
            m[ind].pno=p[i].no;
            p[i].b=m[ind].b=0;        
           }
    }
     print(m,k);
}
   
void firstfit(fit m[],fit p[],int n,int k)
{
    for(int i=0;i<k;i++)
    {
        for(int j=0;j<n;j++)
        {
            if((p[i].a<=m[j].a) && (p[i].b==-1 && m[j].b==-1))
            {
                cout<<j+1<<" "<<i+1<<" "<<p[i].a<<endl;
                 p[i].b=m[j].b=0;
                
            }
        }
    }
   //print(m,n);
    
}
int main()
{
    int n,k;
    cout<<"enter the number of blocks"<<endl;
    cin>>n;
    cout<<"enter the block sizes"<<endl;
    fit m[n];
    for(int i=0;i<n;i++)
    {
        cin>>m[i].a;
        m[i].b=-1;
        m[i].no=i+1;
        m[i].pno=0;
    }
    cout<<"enter the number of process"<<endl;
    cin>>k;
    fit p[k];
    cout<<"enter the process sizes"<<endl;
    for(int i=0;i<k;i++)
    {

       cin>>p[i].a;
       p[i].no=i+1;
       p[i].b=-1;
      
    }
    //firstfit(m,p,n,k);
    cout<<endl;
    bestfit(m,p,n,k);
    //cout<<endl;
    //worstfit(m,p,n,k);


}
