#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,k;
    cin>>n;
    vector<int>v;
    int x;
    for(int i=0;i<n;i++)
    {
        cin>>x;
        v.push_back(x);
    }
    int count=0;
    cin>>k;
    int min=INT_MAX;
    int ind=-1;
    for(int i=0;i<n;i++)
    {
      if(abs(k-v[i])<min)
      {
        min=abs(k-v[i]);  
        ind=i;
      } 
    }
    cout<<k<<" - "<<v[ind]<<endl;
    count+=abs(k-v[ind]);
    k=v[ind];
    v[ind]=99999;
    min=INT_MAX;
    for(int i=0;i<n-1;i++)
    {
        min=INT_MAX;
        for(int j=0;j<n;j++)
        {
           if(abs(k-v[j])<min)
           {
              min=abs(k-v[j]);
              ind=j;
           }
        }
        count+=min;
        cout<<k<<" - "<<v[ind]<<endl;
        k=v[ind];
        v[ind]=99999;
    }
    cout<<count<<endl;
    

}