#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,k,x,max;
    cin>>n;
    vector<int>v;
    cout<<"enter the max number of tracks"<<endl;
    cin>>max;
    max--;
    for(int i=0;i<n;i++)
    {
        cin>>x;
        v.push_back(x);
    }
    int count=0;
    cin>>k;
    v.push_back(k);
    int ind=-1;
    n=v.size();
    sort(v.begin(),v.end());
    for(int i=0;i<n;i++)
    {
        if(v[i]==k){
         ind=i;
         break;
        }
    }
    for(int i=ind;i<n-1;i++)
    {
        count+=v[i+1]-v[i];
        cout<<v[i+1]<<"-"<<v[i]<<endl;
    }
    cout<<v[n-1]<<" - "<<v[ind-1]<<endl;
    count+=v[n-1]-v[ind-1];
    for(int i=ind-1;i>0;i--)
    {
        count+=v[i]-v[i-1];
        cout<<v[i]<<"-"<<v[i-1]<<endl;
        } 
        cout<<count<<endl;  
 }
