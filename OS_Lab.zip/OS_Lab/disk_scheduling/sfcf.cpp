#include<bits/stdc++.h>
using namespace std;
int main()
{
  int n,x,k;
  cin>>n;
  vector<int>v;
  for(int i=0;i<n;i++)
  {
      cin>>x;
      v.push_back(x);
  }
  cin>>k;
  int count=0;
  count+=abs(k-v[0]);
  cout<<v[0]<<" - "<<k<<endl;
  for(int i=1;i<n;i++)
  {
    count+=abs(v[i]-v[i-1]);
    cout<<v[i]<<" - "<<v[i-1]<<endl;
  }
  cout<<count;

}