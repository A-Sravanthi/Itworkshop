 #include<bits/stdc++.h>
 using namespace std;
 int main(){
 int n,k,x,max;
    vector<int>v;
    cout<<"enter the max number of tracks"<<endl;
    cin>>max;
    cout<<"enter the no of tracks"<<endl;
    cin>>n;
    max--;
    for(int i=0;i<n;i++)
    {
        cin>>x;
        v.push_back(x);
    }
    int count=0;
    cout<<"enter the curr position"<<endl;
    cin>>k;
    v.push_back(k);
    int ind=-1;
    n=v.size();
    sort(v.begin(),v.end());
    for(int i=0;i<n;i++)
    {
        if(v[i]==k){
         ind=i;
         break;
        }
    }
    for(int i=ind;i<n-1;i++)
    {
        count+=v[i+1]-v[i];
        cout<<v[i+1]<<" - "<<v[i]<<endl;
    }
    count+=max-v[n-1];
    cout<<max<<" - "<<v[n-1]<<endl;
    count+=max;
    cout<<max<<" - "<<"0"<<endl;
    count+=v[0];
    cout<<"0"<<" - "<<v[0]<<endl;
    for(int i=1;i<ind;i++)
    {
       count+=v[i]-v[i-1];
       cout<<v[i]<<" - "<<v[i-1]<<endl;
    }
    cout<<count<<endl;
 }